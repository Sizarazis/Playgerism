﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slot : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}

    public Line currentLine;
    public Slot prevSlot;
    public Slot nextSlot;
    public int  relPosition;

    // Update is called once per frame
    void Update () {

    }
}
